=====
About
=====

Tidelift
========

If you use this plugin in a corporate environment, consider supporting ``pytest-mock`` via `Tidelift <https://tidelift.com/subscription/pkg/pypi-pytest_mock?utm_source=pypi-pytest-mock&utm_medium=referral&utm_campaign=readme>`_.

License
=======

Distributed under the terms of the `MIT`_ license.

Security contact information
============================

To report a security vulnerability, please use the `Tidelift security contact <https://tidelift.com/security>`__. Tidelift will coordinate the fix and disclosure.

.. _MIT: https://github.com/pytest-dev/pytest-mock/blob/master/LICENSE
