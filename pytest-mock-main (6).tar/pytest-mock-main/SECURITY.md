## Security contact information

This project is not used in production, so there should be no security concerns.

However as part of the Tidelift offering, the policy to report a security vulnerability is to use the
[Tidelift security contact](https://tidelift.com/security).

Tidelift will coordinate the fix and disclosure.
